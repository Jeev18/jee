Project title: Guessing Game

The date and time at which make was run:
Tue Jun 19 16:34:53 CDT 2018

The number of lines of code contained in guessinggame.sh:
23
